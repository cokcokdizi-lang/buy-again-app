Separate testing source, prepared 16 November 2026.
Display name: Buy Again - Backup & Share Test
Android applicationId: com.buyagaindontbuyagain.app.backupsharetest
This is a source ZIP, not an installable APK. Build with the existing GitHub Actions workflow after uploading this ZIP and updating the extract filename.
Only the applicationId, displayed app name and versionName have been changed from the uploaded Backup and Share fixes source. No functionality has been tested.
The separate applicationId gives the test app separate app data storage from TEST 4. Do not uninstall or clear data for TEST 4 with 61 items. Test with dummy data.
