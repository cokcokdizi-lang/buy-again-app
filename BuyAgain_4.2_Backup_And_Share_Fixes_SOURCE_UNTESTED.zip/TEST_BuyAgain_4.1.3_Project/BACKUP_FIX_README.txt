Buy Again / Don't Buy Again — proposed targeted backup correction only
Source: TEST_4_LATEST_BUYAGAIN_FINAL_TEST_READY_FOR_GITHUB_2026-09-03.zip

Changed: app/src/main/assets/index.html only.
Backup My Items now calls the pre-existing AndroidBridge.saveBackup() method, which opens the Android CreateDocument save picker. Success is displayed only after Android reports a completed write. Cancellation/failure reports that no backup was saved. The backup payload and restore logic are unchanged.

IMPORTANT: This is an UNTESTED SOURCE PATCH, not a tested APK. Do not install or replace the existing app containing 61 items until an independent backup and a safe migration procedure are verified. Verify installed app identity and run full phone regression testing.
